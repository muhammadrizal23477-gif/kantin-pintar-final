# Kantin Pintar — Server

Backend + aplikasi web (PWA) untuk Kantin Pintar. Repo ini siap dideploy ke [Render.com](https://render.com) sebagai Web Service.

## Isi folder
- `server.js` — server Express (API data + menyajikan halaman web)
- `data.json` — tempat data (menu, pesanan, promo) disimpan
- `package.json` — daftar dependensi Node.js
- `app/` — tampilan web (index.html, manifest.json untuk PWA, ikon, service worker)
- `render.yaml` — konfigurasi otomatis untuk Render (opsional, Render bisa baca ini langsung)

## Cara deploy ke Render

1. Upload seluruh isi repo ini ke GitHub (public repo).
2. Buka https://render.com, daftar/masuk (bisa pakai akun GitHub).
3. Klik **New** > **Web Service**, pilih repo ini.
4. Render otomatis mengisi pengaturan dari `render.yaml`:
   - Build Command: `npm install`
   - Start Command: `node server.js`
   - Plan: Free
   Kalau tidak otomatis terbaca, isi manual seperti di atas.
5. Klik **Create Web Service**, tunggu proses build 2-5 menit.
6. Setelah status "Live", akan muncul alamat seperti:
   `https://kantin-pintar.onrender.com`

## Menjadikan aplikasi Android (setelah server live)

**Cara termudah — Add to Home Screen:**
1. Di HP Android, buka Chrome, kunjungi alamat Render kamu.
2. Ketuk menu titik tiga (⋮) > **Add to Home screen** / **Install app**.
3. Selesai — muncul ikon aplikasi "Kantin Pintar" di layar utama, tampil full-screen tanpa address bar.

**Cara file .apk asli (opsional):**
1. Buka https://www.pwabuilder.com, masukkan alamat Render kamu.
2. Klik **Start** > **Package for Store** > **Android** > **Generate/Download**.
3. Bagikan file `.apk` yang dihasilkan.

## Catatan
- Paket gratis Render akan "tidur" setelah ~15 menit tidak diakses, dan butuh ~30-60 detik untuk bangun kembali saat diakses lagi — ini normal.
- Semua data tersimpan di server ini (`data.json`), bukan di perangkat masing-masing pengguna. Backup berkala disarankan.
- Jangan bagikan alamat Render secara publik karena tidak ada kata sandi tambahan di level server (hanya login di dalam aplikasi).
